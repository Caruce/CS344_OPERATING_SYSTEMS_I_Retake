#compile the program by using the following command
gcc --std=gnu99 -o movies_by_year movies_by_year.c

#run the program by using the following command
./movies_by_year
