#compile the program by using the following command
gcc --std=gnu99 -o smallsh smallsh.c

#run the program by using the following command
./p3testscript > mytestresults 2>&1
