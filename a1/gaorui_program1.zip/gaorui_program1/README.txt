#compile the program by using the following command
gcc --std=gnu99 -o movies movies.c

#run the program by using the following command
./movies movies_sample_1.csv
